import whisper
import os
import json

# Branding setup
STUDIO_NAME = "Aditya AI Studio"

def generate_smart_subtitles(clip_filename):
    print(f"[{STUDIO_NAME}] Initializing AI Subtitle Engine...")
    
    # Path configuration
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    input_video_path = os.path.join(base_dir, "exports", "clips", clip_filename)
    export_subs_dir = os.path.join(base_dir, "exports", "subtitles")
    
    # Failsafe: Check if folders exist
    if not os.path.exists(export_subs_dir):
        os.makedirs(export_subs_dir)
        
    if not os.path.exists(input_video_path):
        return f"Error: File {clip_filename} not found in exports/clips folder."

    print(f"[{STUDIO_NAME}] Loading Whisper AI Model (Base)...")
    # Tum ise 'small' ya 'medium' kar sakte ho better accuracy ke liye
    model = whisper.load_model("base") 
    
    print(f"[{STUDIO_NAME}] Transcribing & Applying Dynamic Styles...")
    result = model.transcribe(input_video_path)
    
    dynamic_subtitles = []
    
    # Action/Emotion keywords for dynamic styling
    action_words = ['fight', 'attack', 'kill', 'power', 'fast', 'smash']
    sad_words = ['cry', 'sad', 'alone', 'why', 'pain']

    for segment in result['segments']:
        text = segment['text'].strip().lower()
        
        # 10x Verified Logic: Context checking for UI Design
        if any(word in text for word in action_words):
            style = "anime-action" # Red, Bold, Shake animation
        elif any(word in text for word in sad_words):
            style = "anime-sad"    # White, Soft, Fade animation
        else:
            style = "anime-normal" # Yellow, Pop animation
            
        dynamic_subtitles.append({
            "id": segment['id'],
            "start": round(segment['start'], 2),
            "end": round(segment['end'], 2),
            "text": segment['text'].strip(),
            "style": style
        })

    # Save to JSON for Frontend/Render Engine to use
    json_filename = clip_filename.replace('.mp4', '.json')
    output_json_path = os.path.join(export_subs_dir, json_filename)
    
    with open(output_json_path, 'w', encoding='utf-8') as f:
        json.dump(dynamic_subtitles, f, indent=4, ensure_ascii=False)
        
    print(f"[{STUDIO_NAME}] Success! Subtitles saved in: {export_subs_dir}/{json_filename}")
    return output_json_path

# Test run command (jab exports/clips me 'aditya_clip_000.mp4' ho)
# generate_smart_subtitles('aditya_clip_000.mp4')
