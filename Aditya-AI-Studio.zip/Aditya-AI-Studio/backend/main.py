from fastapi import FastAPI, UploadFile, File, BackgroundTasks
from fastapi.responses import JSONResponse
import os
import sys
import shutil

# Branding & App Setup
STUDIO_NAME = "Aditya AI Studio"
app = FastAPI(title=f"{STUDIO_NAME} - Core API", version="2.0")

# Setup Paths for importing our engines
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)

# 10x Verified Imports
try:
    # Hyphens ki jagah underscore folders mein use karna standard practice hai, 
    # par system path append hone ke baad hum directly import kar sakte hain.
    # Note: Python import ke liye folder name me dash (-) error deta hai.
    # Tumhare folder names 'render-engine' ko 'render_engine' me rename karna padega.
    from render_engine.video_cutter import process_and_cut_video
    from subtitle_engine.subtitle_generator import generate_smart_subtitles
except ImportError as e:
    print(f"[{STUDIO_NAME}] Import Error: Folder names me dash (-) mat use karo. Rename them to use underscores (_). Error: {e}")

UPLOAD_DIR = os.path.join(base_dir, "uploads")

@app.get("/")
def read_root():
    return {"message": f"Welcome to {STUDIO_NAME} API. System Online."}

@app.post("/upload-and-process/")
async def upload_video(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    print(f"[{STUDIO_NAME}] Receiving File: {file.filename}...")
    
    # Save uploaded file
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    print(f"[{STUDIO_NAME}] File Saved. Starting processing in background...")
    
    # Background processing taaki website hang na ho
    background_tasks.add_task(run_full_pipeline, file.filename)
    
    return JSONResponse(content={
        "status": "success",
        "message": "Video upload ho gayi hai. Aditya AI Studio backend me processing start kar raha hai.",
        "filename": file.filename
    })

def run_full_pipeline(filename):
    print(f"\n--- [{STUDIO_NAME}] STARTING PIPELINE FOR {filename} ---")
    
    # Step 1: Cut Video & Bypass Copyright
    cut_success = process_and_cut_video(filename, clip_duration=60)
    
    if cut_success:
        # Step 2: Generate Subtitles for the first clip as an example
        first_clip_name = "aditya_clip_000.mp4" 
        generate_smart_subtitles(first_clip_name)
        print(f"--- [{STUDIO_NAME}] PIPELINE COMPLETE ---")
    else:
        print(f"--- [{STUDIO_NAME}] PIPELINE FAILED AT CUTTING STAGE ---")

# Server Run Command (Neeche likha hai)
