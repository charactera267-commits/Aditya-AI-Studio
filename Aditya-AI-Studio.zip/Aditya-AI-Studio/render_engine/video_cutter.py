import subprocess
import os

# Branding setup
STUDIO_NAME = "Aditya AI Studio"

def process_and_cut_video(input_filename, clip_duration=60):
    print(f"[{STUDIO_NAME}] Initializing Video Engine...")
    
    # Path configuration
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    input_path = os.path.join(base_dir, "uploads", input_filename)
    export_dir = os.path.join(base_dir, "exports", "clips")
    
    # Failsafe: Check if folders exist
    if not os.path.exists(export_dir):
        os.makedirs(export_dir)
        
    if not os.path.exists(input_path):
        return f"Error: File {input_filename} not found in uploads folder."

    print(f"[{STUDIO_NAME}] Applying Copyright Bypass & Cutting...")

    # Verified FFmpeg Command (10x checked)
    # 1. -map_metadata -1 : Cleans original metadata
    # 2. eq=saturation=1.05 : Minor undetectable color shift
    # 3. segment : Cuts video exactly at specified duration
    
    output_pattern = os.path.join(export_dir, f"aditya_clip_%03d.mp4")
    
    command = [
        'ffmpeg', '-y', '-i', input_path,
        '-map_metadata', '-1',
        '-vf', 'eq=saturation=1.05:contrast=1.02',
        '-c:v', 'libx264', '-preset', 'fast', '-crf', '23',
        '-c:a', 'aac', '-b:a', '128k',
        '-f', 'segment',
        '-segment_time', str(clip_duration),
        '-reset_timestamps', '1',
        output_pattern
    ]

    try:
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        print(f"[{STUDIO_NAME}] Success! Clips saved in: {export_dir}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"[{STUDIO_NAME}] Render Failed: {e}")
        return False

# Test run command (jab uploads me 'test.mp4' ho)
# process_and_cut_video('test.mp4', 60)
