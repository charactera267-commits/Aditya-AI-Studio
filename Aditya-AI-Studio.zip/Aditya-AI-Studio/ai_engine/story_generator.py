import os
import asyncio
import edge_tts
import json

# Branding Setup
STUDIO_NAME = "Aditya AI Studio"

async def generate_voiceover(text, output_audio_path):
    # Professional Hindi/English mixed voice (Aarav)
    voice = "en-IN-PrabhatNeural" 
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(output_audio_path)
    return True

def generate_cinematic_story(prompt, project_name="Nazar_Ka_Sukoon_Part_1"):
    print(f"[{STUDIO_NAME}] Initializing AI Story Engine...")
    
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    export_dir = os.path.join(base_dir, "exports", "story_videos", project_name)
    
    if not os.path.exists(export_dir):
        os.makedirs(export_dir)

    print(f"[{STUDIO_NAME}] Generating Script for: {prompt}")
    
    # Yahan tum OpenAI API ya local LLM lagaoge. Abhi hum structured dummy data le rahe hain.
    # Hum seedha Part 1 se ek-ek karke cinematic scenes banane par focus karenge.
    ai_script = {
        "title": project_name,
        "scenes": [
            {
                "scene_number": 1,
                "visual_prompt": f"Hyper-realistic 8K cinematic, IMAX 70mm style, {prompt}, Unreal Engine 5 render, highly detailed",
                "narration": "Yeh kahani shuru hoti hai ek aisi jagah se, jahan khamoshi bhi baatein karti hai..."
            },
            {
                "scene_number": 2,
                "visual_prompt": "Cinematic pan shot, lo-fi aesthetic lighting, slow motion 8k",
                "narration": "Aur har pal ek naya raaz kholta hai."
            }
        ]
    }
    
    # Save Script
    script_path = os.path.join(export_dir, "script.json")
    with open(script_path, 'w', encoding='utf-8') as f:
        json.dump(ai_script, f, indent=4, ensure_ascii=False)

    print(f"[{STUDIO_NAME}] Generating Voiceovers...")
    
    # Run Async Voice Generation
    for scene in ai_script['scenes']:
        audio_filename = os.path.join(export_dir, f"scene_{scene['scene_number']}_audio.mp3")
        # Run event loop for edge-tts
        asyncio.run(generate_voiceover(scene['narration'], audio_filename))
        print(f"  -> Generated Audio for Scene {scene['scene_number']}")

    print(f"[{STUDIO_NAME}] Visual Prompts Ready for Video API (Kling/Wan/Runway).")
    print(f"[{STUDIO_NAME}] Output saved to: {export_dir}")
    
    return script_path

# Test Run Command:
# generate_cinematic_story("A boy walking alone in a dark cyberpunk city, neon lights")
