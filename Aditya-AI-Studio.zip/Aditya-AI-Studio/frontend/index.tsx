'use client';
import { useState } from 'react';

// Branding setup
const STUDIO_NAME = "Aditya AI Studio";
const CREATOR_NAME = "Aditya Tripathi";

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<string>("Waiting for upload...");
  const [isUploading, setIsUploading] = useState<boolean>(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setStatus(`Selected: ${e.target.files[0].name}`);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      setStatus("Pehle ek video select karo!");
      return;
    }

    setIsUploading(true);
    setStatus("Uploading to Aditya AI Engine...");

    const formData = new FormData();
    formData.append("file", file);

    try {
      // Connecting to your FastAPI backend
      const response = await fetch("http://127.0.0.1:8000/upload-and-process/", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      
      if (response.ok) {
        setStatus(`Success: ${data.message}`);
      } else {
        setStatus("Upload failed. Backend check karo.");
      }
    } catch (error) {
      setStatus("Error: API se connect nahi ho paya. Kya FastAPI run ho rahi hai?");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center p-10 font-sans">
      
      {/* Header Section */}
      <header className="w-full max-w-4xl flex justify-between items-center mb-16 border-b border-purple-600 pb-4">
        <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
          {STUDIO_NAME} V2
        </h1>
        <div className="text-sm text-gray-400">
          Built by <span className="text-purple-500 font-bold tracking-wider">{CREATOR_NAME}</span>
        </div>
      </header>

      {/* Main Upload Box */}
      <main className="w-full max-w-2xl bg-black border border-purple-500/30 rounded-2xl p-8 shadow-[0_0_50px_-12px_rgba(168,85,247,0.3)] text-center">
        <h2 className="text-2xl font-bold mb-2">AI Video Cutter & Subtitles</h2>
        <p className="text-gray-400 mb-8 text-sm">Upload your long anime video. AI will bypass copyright & auto-clip it.</p>
        
        <div className="border-2 border-dashed border-gray-700 rounded-xl p-10 hover:border-purple-500 transition-colors">
          <input 
            type="file" 
            accept="video/mp4" 
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700 mb-4 cursor-pointer"
          />
        </div>

        {/* Status & Upload Button */}
        <div className="mt-6 flex flex-col items-center gap-4">
          <p className="text-sm font-mono text-purple-300">{status}</p>
          
          <button 
            onClick={handleUpload}
            disabled={isUploading || !file}
            className={`px-8 py-3 rounded-full font-bold text-white transition-all ${
              isUploading || !file 
                ? 'bg-gray-600 cursor-not-allowed' 
                : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:scale-105 shadow-lg shadow-purple-500/50'
            }`}
          >
            {isUploading ? 'Processing AI...' : 'Start AI Engine'}
          </button>
        </div>
      </main>

    </div>
  );
}
